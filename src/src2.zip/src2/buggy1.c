// Buggy example for help50

#include <stdio.h>

int main(void)
{
    string s = get_string("Name: ");
    printf("hello, %s\n", s);
}
